import React from "react";

const Header=()=>{
    return(
        <div>
            <h1 className="bg-warning">Employee Management App</h1>
        </div>
    )
}
export default Header
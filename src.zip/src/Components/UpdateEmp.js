import React from "react";
function UpdateEmp(props) {
    

    return (
        <> 
          <h1>Update Employee </h1>  
          {/* add update employee form */}
        </>
    )
}

export default UpdateEmp